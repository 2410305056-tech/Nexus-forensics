# 🛡️ Nexus Forensics: Shadow-Core V2

The high-performance, forensic-grade backend engine for digital crime investigation.

## 🚀 Key Features
- **Ghost Cache**: Ultra-fast Redis layer with binary serialization for sub-2ms response times.
- **Chain-of-Custody**: Automatic HMAC SHA-256 integrity hashing for every evidence entry.
- **AI-Impact Scoring**: Heuristic intelligence engine that predicts threat severity (extensible for LLMs).
- **Binary Postgres Access**: Uses `pgx/v5` for raw-speed database communication without ORM overhead.
- **Real-Time Pub/Sub**: WebSocket-ready event broadcasting via Redis.

## 🛠️ Prerequisites
- Go 1.21+
- PostgreSQL 15+
- Redis 7+

## 📦 Installation

1. Clone the repository and install dependencies:
    go mod tidy

2. Setup environment variables:
    cp .env.example .env

3. Configure your `DATABASE_URL` and `REDIS_URL` in the `.env` file.

## 🏃 Running the Application

### Local Development:
    go run cmd/api/main.go

### Using Docker:
    docker build -t shadow-core .
    docker run -p 3000:3000 --env-file .env shadow-core

## 📡 API Endpoints

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| GET | `/api/v1/health` | Engine status and health check |
| POST | `/api/v1/cases` | Create a new forensic case with AI scoring |

### Example Request (Create Case)
    POST /api/v1/cases
    {
      "title": "Operation Ghost-Leak",
      "description": "Analysis of encrypted PCAP files showing data breach in Sector 7.",
      "agent": "Agent_Zero"
    }

## 🔒 Security & Performance
- **Immutable Logs**: Audit logs are generated for every write operation to ensure forensic integrity.
- **Connection Pooling**: Database connections are pooled and tuned for high-concurrency Railway environments.
- **Middleware**: Includes CORS protection and structured logging.

## 📂 Project Structure
- `cmd/api`: Entry point for the Fiber application.
- `internal/application`: Business logic (AI Scoring, Forensic integrity).
- `internal/domain`: Data models and core entities.
- `internal/infrastructure`: DB and Redis connections.
- `internal/transport`: HTTP handlers and routing.
