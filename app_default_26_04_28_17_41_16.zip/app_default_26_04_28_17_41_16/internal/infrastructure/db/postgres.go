package db

import (
	"context"
	"log"
	"os"

	"github.com/jackc/pgx/v5/pgxpool"
)

func ConnectPostgres() *pgxpool.Pool {
	connStr := os.Getenv("DATABASE_URL")
	if connStr == "" {
		log.Fatal("DATABASE_URL environment variable is not set")
	}

	config, err := pgxpool.ParseConfig(connStr)
	if err != nil {
		log.Fatal("Failed to parse DB config:", err)
	}

	// Performance Tuning for Railway/Production
	config.MaxConns = 20
	config.MinConns = 5

	pool, err := pgxpool.NewWithConfig(context.Background(), config)
	if err != nil {
		log.Fatal("Unable to connect to database:", err)
	}

	log.Println("Connected to PostgreSQL via binary protocol (pgx/v5)")
	return pool
}

func InitSchema(pool *pgxpool.Pool) {
	schema := `
	CREATE TABLE IF NOT EXISTS cases (
		id UUID PRIMARY KEY,
		title TEXT NOT NULL,
		description TEXT,
		status TEXT DEFAULT 'OPEN',
		impact_score INT DEFAULT 0,
		evidence_hash TEXT,
		assigned_agent TEXT,
		created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
		updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
	);

	CREATE TABLE IF NOT EXISTS audit_logs (
		id UUID PRIMARY KEY,
		case_id UUID REFERENCES cases(id),
		action TEXT,
		actor TEXT,
		timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
		prev_hash TEXT,
		curr_hash TEXT
	);
	`
	_, err := pool.Exec(context.Background(), schema)
	if err != nil {
		log.Fatal("Failed to initialize schema:", err)
	}
}
