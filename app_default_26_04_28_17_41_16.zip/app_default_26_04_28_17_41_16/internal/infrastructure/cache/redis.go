package cache

import (
	"context"
	"encoding/json"
	"log"
	"os"
	"time"

	"github.com/redis/go-redis/v9"
)

type GhostCache struct {
	Client *redis.Client
	Ctx    context.Context
}

func NewGhostCache() *GhostCache {
	addr := os.Getenv("REDIS_URL")
	if addr == "" {
		addr = "redis://localhost:6379"
	}

	opt, err := redis.ParseURL(addr)
	if err != nil {
		log.Fatal("Invalid Redis URL:", err)
	}

	rdb := redis.NewClient(opt)
	return &GhostCache{
		Client: rdb,
		Ctx:    context.Background(),
	}
}

func (g *GhostCache) Set(key string, value interface{}, expiration time.Duration) error {
	data, err := json.Marshal(value)
	if err != nil {
		return err
	}
	return g.Client.Set(g.Ctx, key, data, expiration).Err()
}

func (g *GhostCache) Get(key string, dest interface{}) error {
	val, err := g.Client.Get(g.Ctx, key).Result()
	if err != nil {
		return err
	}
	return json.Unmarshal([]byte(val), dest)
}

func (g *GhostCache) PublishUpdate(channel string, message interface{}) {
	data, _ := json.Marshal(message)
	g.Client.Publish(g.Ctx, channel, data)
}
