package application

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"os"
	"time"

	"github.com/google/uuid"
	"github.com/nexus-forensics/shadow-core-v2/internal/domain"
	"github.com/nexus-forensics/shadow-core-v2/internal/infrastructure/cache"
	"github.com/jackc/pgx/v5/pgxpool"
)

type ForensicService struct {
	db    *pgxpool.Pool
	cache *cache.GhostCache
}

func NewForensicService(db *pgxpool.Pool, cache *cache.GhostCache) *ForensicService {
	return &ForensicService{db: db, cache: cache}
}

// GenerateChainOfCustodyHash creates an immutable HMAC of the case data
func (s *ForensicService) GenerateChainOfCustodyHash(c domain.ForensicCase) string {
	secret := os.Getenv("HMAC_SECRET")
	payload := fmt.Sprintf("%s|%s|%s|%s", c.ID, c.Title, c.Description, c.Status)
	h := hmac.New(sha256.New, []byte(secret))
	h.Write([]byte(payload))
	return hex.EncodeToString(h.Sum(nil))
}

func (s *ForensicService) CreateCase(ctx context.Context, title, desc, agent string) (*domain.ForensicCase, error) {
	c := &domain.ForensicCase{
		ID:            uuid.New(),
		Title:         title,
		Description:   desc,
		Status:        domain.StatusOpen,
		AssignedAgent: agent,
		CreatedAt:     time.Now(),
		UpdatedAt:     time.Now(),
	}

	// Calculate AI Impact Score (Mocking LLM analysis logic)
	// In production, this would call OpenAI API
	c.ImpactScore = s.calculateImpact(desc)
	c.EvidenceHash = s.GenerateChainOfCustodyHash(*c)

	// Persist to Postgres
	query := `INSERT INTO cases (id, title, description, status, impact_score, evidence_hash, assigned_agent, created_at, updated_at) 
			  VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`
	
	_, err := s.db.Exec(ctx, query, c.ID, c.Title, c.Description, c.Status, c.ImpactScore, c.EvidenceHash, c.AssignedAgent, c.CreatedAt, c.UpdatedAt)
	if err != nil {
		return nil, err
	}

	// Cache for Performance (Ghost Cache)
	s.cache.Set(fmt.Sprintf("case:%s", c.ID), c, time.Hour*24)
	
	// Real-time Broadcast
	s.cache.PublishUpdate("forensic_feed", c)

	return c, nil
}

func (s *ForensicService) calculateImpact(desc string) int {
	// Simple heuristic engine - could be swapped for OpenAI
	score := 10
	keywords := map[string]int{"breach": 40, "malware": 30, "pcap": 20, "critical": 50, "leak": 45}
	for word, weight := range keywords {
		if contains(desc, word) {
			score += weight
		}
	}
	if score > 100 { return 100 }
	return score
}

func contains(s, substr string) bool {
	return len(s) >= len(substr) && s != "" && substr != ""
}
