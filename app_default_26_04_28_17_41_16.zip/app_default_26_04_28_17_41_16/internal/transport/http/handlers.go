package http

import (
	"github.com/gofiber/fiber/v3"
	"github.com/nexus-forensics/shadow-core-v2/internal/application"
)

type Handler struct {
	service *application.ForensicService
}

func NewHandler(service *application.ForensicService) *Handler {
	return &Handler{service: service}
}

type CreateCaseRequest struct {
	Title       string `json:"title" validate:"required"`
	Description string `json:"description" validate:"required"`
	Agent       string `json:"agent" validate:"required"`
}

func (h *Handler) CreateCase(c fiber.Ctx) error {
	var req CreateCaseRequest
	if err := c.Bind().JSON(&req); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request payload"})
	}

	forensicCase, err := h.service.CreateCase(c.Context(), req.Title, req.Description, req.Agent)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to create forensic case: " + err.Error()})
	}

	return c.Status(201).JSON(forensicCase)
}

func (h *Handler) HealthCheck(c fiber.Ctx) error {
	return c.JSON(fiber.Map{
		"status": "online",
		"engine": "Shadow-Core V2",
		"uptime": "100%",
	})
}
