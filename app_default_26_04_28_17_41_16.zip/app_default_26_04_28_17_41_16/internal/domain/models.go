package domain

import (
	"time"
	"github.com/google/uuid"
)

type CaseStatus string

const (
	StatusOpen       CaseStatus = "OPEN"
	StatusInAnalysis CaseStatus = "ANALYSIS"
	StatusClosed     CaseStatus = "CLOSED"
	StatusFlagged    CaseStatus = "FLAGGED"
)

type ForensicCase struct {
	ID            uuid.UUID  `json:"id" redis:"id"`
	Title         string     `json:"title" redis:"title"`
	Description   string     `json:"description" redis:"description"`
	Status        CaseStatus `json:"status" redis:"status"`
	ImpactScore   int        `json:"impact_score" redis:"impact_score"` // 0-100 AI Generated
	EvidenceHash  string     `json:"evidence_hash" redis:"evidence_hash"` // Chain of Custody HMAC
	AssignedAgent string     `json:"assigned_agent" redis:"assigned_agent"`
	CreatedAt     time.Time  `json:"created_at" redis:"created_at"`
	UpdatedAt     time.Time  `json:"updated_at" redis:"updated_at"`
}

type AuditLog struct {
	ID        uuid.UUID `json:"id"`
	CaseID    uuid.UUID `json:"case_id"`
	Action    string    `json:"action"`
	Actor     string    `json:"actor"`
	Timestamp time.Time `json:"timestamp"`
	PrevHash  string    `json:"prev_hash"`
	CurrHash  string    `json:"curr_hash"`
}

type IntelligenceReport struct {
	CaseID      uuid.UUID `json:"case_id"`
	ThreatLevel string    `json:"threat_level"`
	Summary     string    `json:"summary"`
	Entities    []string  `json:"entities"`
}
