package main

import (
	"log"
	"os"

	"github.com/gofiber/fiber/v3"
	"github.com/gofiber/fiber/v3/middleware/cors"
	"github.com/gofiber/fiber/v3/middleware/logger"
	"github.com/joho/godotenv"
	"github.com/nexus-forensics/shadow-core-v2/internal/application"
	"github.com/nexus-forensics/shadow-core-v2/internal/infrastructure/cache"
	"github.com/nexus-forensics/shadow-core-v2/internal/infrastructure/db"
	"github.com/nexus-forensics/shadow-core-v2/internal/transport/http"
)

func main() {
	// 1. Load Config
	_ = godotenv.Load()

	// 2. Initialize Infrastructure
	database := db.ConnectPostgres()
	defer database.Close()
	db.InitSchema(database)

	ghostCache := cache.NewGhostCache()

	// 3. Setup Services
	forensicService := application.NewForensicService(database, ghostCache)

	// 4. Initialize Fiber App
	app := fiber.New(fiber.Config{
		AppName: "Nexus Forensics Shadow-Core V2",
	})

	// 5. Global Middleware
	app.Use(logger.New())
	app.Use(cors.New())

	// 6. Routes
	h := http.NewHandler(forensicService)
	
	api := app.Group("/api/v1")
	api.Get("/health", h.HealthCheck)
	api.Post("/cases", h.CreateCase)

	// 7. Start Server
	port := os.Getenv("PORT")
	if port == "" {
		port = "3000"
	}

	log.Printf("Shadow-Core V2 engine starting on port %s", port)
	if err := app.Listen(":" + port); err != nil {
		log.Fatal(err)
	}
}
